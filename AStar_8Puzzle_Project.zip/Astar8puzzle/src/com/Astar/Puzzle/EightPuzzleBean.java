package com.Astar.Puzzle;

/**
 * Common parent class containing variables declarations that can be used by both Heuristics
 */
public class EightPuzzleBean {
	
	public int aStarDistance;
	public int[][] stateOfPuzzle;
	public int level;
	
}
